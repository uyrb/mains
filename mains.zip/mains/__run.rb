
Dir.chdir File.dirname((__FILE__))
require $0 = "./AnneRose/__index.rb"
