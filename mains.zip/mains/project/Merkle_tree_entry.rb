#coding:utf-8
require "__dev/req" if $0 ==__FILE__

Merkle_tree.new.Main :top_node do |o|
  o.Code do
    # if o.task.empty? then o.Flandre << :stg
    if o.task.empty? then o.Flandre << File.basename($0,".*").to_sym
    end
    -> &b do lambda do |f|
        lambda{|x|lambda{|y| f[x[x]] [y]}}[
          lambda{|x|lambda{|y| f[x[x]] [y]}}]
      end[ lambda{|f|lambda{|n| b[n , &f] }}]
    end.yield do | o , * , &f |
      case o.Flandre.shift
      when nil then true
      # when -> rb do (p rb);false end
      when -> rb do o.Object_create rb end
      # when -> rb do o.Scene_loading rb end
      when -> rb do
          o.Task :"__#{rb}_task" do |o|
            o.Code do
              o.Main :"#{rb}" do |o|
                o.Scene_create rb
                o.Code do
                  f[ [o , nil] ]
                end # code
              end # main
            end # co
          end # tas
        end #lm
      end # while not o.Flandre.empty? # case
    end[ [ o , nil ] ] # recursion
  end # code do
end # main
