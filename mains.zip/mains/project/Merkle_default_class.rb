#coding:utf-8
require "__dev/req"  if $0 ==__FILE__

# シーン初期化時に入れるかも
->{
  o._ms_send({
   to: nil,
   type: :set_state,
   payload: ["scene"],
  })
  o._ms_send({
   to: nil,
   type: :get_state,
   payload: [],
  })
}

module Node_project
  # def Object_create rb
  #   [
  #     /\Aobject_(.+)/ , ->o,rb{ o.__Node_create rb }, # ファイルからロード object_user.rb
  #     /\Afunc_(.+)/ ,   ->o,rb{ send(rb) }, #  関数を呼び出し func_aa
  #   ].each_slice 2 do | reg , f |
  #     if rb =~ reg
  #       self.Task :"__#{rb}_task" do |o|
  #         f.call o , rb
  #       o.Code{};end
  #       return true
  #     end
  #   end
  #   return false
  # end
  def Object_create rb
    if rb =~ /\Aobject_(.+)/
      send("object_node_maneger" , rb)
      # self.Task :"__#{rb}_task" do |o|
      #   # o.__Node_create rb
      #   o.Code do end
      # end
      return true
    end
    # ファイルではなく関数を呼び出す
    if rb =~ /\Afunc_(.+)/
      send(rb)
      # self.Task :"__#{rb}_task" do |o|
      #   o.Code do o.delete end
      # end
      return true
    end
    return false
  end

  def object_node_maneger rb
    self.__Node_create rb
  end
  def func_aa hs = self.Scarlet[:Flandre].shift
    # self.sym == o.up.sym
    p self.Scarlet[:Flandre]
    p :func_aa
  end
#######
  def Scene_loading rb
    self.Task :"__#{rb}_task_loading" do |o|
      o.Code do
        o.Main :"#{rb}_loading" do |o|
          rb = :loading
          o.Scene_create rb
          o.Code do end # code
        end # main
      end # co
    end # tas
    return false
  end
# Scene Obj 両方で使用
# TOPLEVEL_BINDING.eval(File.read(path), path)
# load .. eval なのでネームスペースに罠あり　::A
  def __Node_create rb
    load_src = "./AnneRose/" + rb.to_s
    #--------- refine ----------
    __Window_refine_do
    file = "#{load_src}/#{File.basename load_src}.rb"
    file = "#{load_src}.rb" unless File.exists?(file)
    # bindingを作ってファイル情報を注入
    def binding_scope file
      bin = binding
      bin.local_variable_set(:__FILE__, file)
      bin.local_variable_set(:__DIR__, File.dirname(file))
      Dir.chdir(bin.local_variable_get(:__DIR__) )
      bin.local_variable_set(:__LINE__, 1)
      bin.local_variable_set(:arghs, self.up.Scarlet[:Flandre].shift)
      bin
    end
    file  = File.expand_path(file)
    bin = binding_scope file
    # eval実行。第三引数にファイル名、第四引数に開始行番号を指定
    warn "[file not found]: #{file}" unless File.exists?(file)
    case (file)
    # when -> rb {  File.exists?(rb) &&    TOPLEVEL_BINDING.eval(File.read(rb), rb)  }
  # when -> rb {  File.exists?(rb) && load(rb , false) }
  # when -> rb {  File.exists?(rb) && load(rb , true) }
    when -> rb { File.exists?(rb) && eval(open(rb).read,bin,file,1); }
    else
      self.Task :__load_src_error do |o| o.Code do
        Window.drawFont(50,  60, "--404 rb file not found--" ,  Font.default)
        Window.drawFont(50,  10, "--#{load_src}--" , Font.default)        
        Window.drawFont_original(50,  160, "--404 rb file not found--" ,  Font.default) if Window.respond_to?(:drawFont_original)
        Window.drawFont_original(50,  110, "--#{load_src}--" , Font.default)  if Window.respond_to?(:drawFont_original)
    end end
  end
  Dir.chdir(File.dirname __dir__) # 戻す
  __Window_refine_end

  end
  def Scene_create rb
    __Node_create rb
    # window update
    self.Task :__window_update do |o| o.Code do # XXX o.MAIN_NODEがこのsymに依存
      Window.sync ; Window.update ; exit if Input.update
    end end
    # //-- Debug --
    self.Task :__debug_code do |o| o.Code do
      p self.sym           if Input.keyPush? K_F3
      self.up.delete       if Input.keyPush? K_F4
      # self.up.delete       if Input.keyPush? K_F5
      self.delete          if Input.keyPush? K_F5
      self.TOP_NODE.delete if Input.keyPush? K_F6
      exit                       if Input.keyPush? K_F9
      exit                       if Input.keyPush? K_F8

      # self.Flandre << :dot         if Input.keyPush? K_1
      # self.Flandre << :menu        if Input.keyPush? K_2
      # self.Flandre << :tree_view   if Input.keyPush? K_3

      Lumia2.screenshot if Input.keyPush? K_F12

    end end if defined?(DEBUG_CODE) && self.DEBUG_CODE.scene_flag

    # end end if self.DEBUG_CODE.scene_flag  &&
    # defined(DEBUG_CODE)
    # @node_self.DEBUG_CODE.des_flag
    # -- Debug --//
  end # AnneRose\title

  # 2層目以降でo.deleteしたとき@node_selfが書き換わるバグ
  # @node_self.upも書き換わってる
  # 打開策で o.upをyieldに渡したものの
  # つまり:menu シーンの制御タスクが :dot_taskのままになってたりする
  # p "o.up.sym---#{o.up.sym}"
  # p "@node_self.up.sym---#{@node_self.up.sym}"
  # ↓ こっちにかえれば node_self減らせる
  # define_singleton_method(:loop) do | &proc |
  def __Window_refine_do
    node_self = self
    Window.class_eval do
      @node_self = node_self
      def self.loop
        @node_self.Task :__window_loop do |o| o.Code do
          yield o.up  # old_code yield @node_self
          # stack.rb レンダーのキュー確認して残ってたら警告表示
          # 警告するものの 残りのキューを Window.draw
          # 本来はSceneのほうで .draw
          $Patchouli_knowledge.render.check_render_queue if $Patchouli_knowledge
        end end
      end
    end # eval
  end
  # refineしたものを通常のWindow.loop に戻す
  def __Window_refine_end
    Window.class_eval do
      def self.loop ; # Window.create rescue p "Window is created"
        while true ; p ":Window.class_eval";
           Window.sync ; Window.update ; exit if Input.update ; yield end end end
  end
end
