#coding:utf-8
require "__dev/req" if $0 ==__FILE__

class Merkle_tree
  include Merkle_tree_m          if defined?(Merkle_tree_m)
  include Merkle_tree_m_ex       if defined?(Merkle_tree_m_ex)
  include DEBUG_CODE_m           if defined?(DEBUG_CODE_m)
  include Node_project           if defined?(Node_project)
  include Node_template          if defined?(Node_template)
  include Node_ms_proc           if defined?(Node_ms_proc)
  include Node_ms_proc_handler   if defined?(Node_ms_proc_handler)

  # include Merkle_tree_m
  # include Merkle_tree_m_ex
  # include DEBUG_CODE_m
  # include Node_project # Object_create Scene_create
  # include Node_template # 実装含む
  # include Node_ms_proc
  # include Node_ms_proc_handler
  # def initialize **_
  #   super
  # end
  def Flandre = @Flandre ||= [] # .extend( AAA )# lazy initialization
  def Scarlet = @Scarlet ||= Hash.new { |h, k| h[k] = [] } # Scarlet[:menu] << [1,2,3]
  def Flandre_Scarlet a,b
    self.up.Flandre << a
    self.up.Scarlet[:Flandre] << b
  end
  def Flandre_Scarlet_res
  end
end
