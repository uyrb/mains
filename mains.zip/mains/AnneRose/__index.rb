
Dir.chdir File.dirname(File.dirname(__FILE__))
$LOAD_PATH.unshift(File.dirname __dir__)
# --- base system ---
# require "./system/debug"
require "./system/tree_task_ex"
require "./system/tree_task"
# --- project API ---
require "dxruby"
# --- project src ---
require "./conf"
# require "./Lib2/rubyex"
# require "./Lib2/Lazy_sound_loader"
# require "./Lib2/L azy_image_loader"
# require "./Lib2/Node_template"
require "./Lib2/Lumia"
#
require "./stack"
# require "./project/key"
# --- run ---
require "./project/Merkle_default_class"
require "./project/Merkle_tree"
require "./project/Merkle_tree_entry"
#
# --- app ---
require "./AnneRose/app_mains.rb"
fn = Pattern_app_move.app_mains

Window.loop do |o|
  o.Scarlet[(__FILE__ + __LINE__.to_s)][0] ||= begin
    o.extend Module.new{attr_accessor :ren}
    o.ren = RenderTarget.new(Window.width, Window.height)
    true
  end
  fn.call o,nil,nil
  # Window.draw_font(40,40,"#{__FILE__}",Font.default)
  Window.draw(0,0,o.ren)
  $Patchouli_knowledge.render.enable = true
  $Patchouli_knowledge.render.draw
  exit if Input.keyDown?(K_ESCAPE)
end
