#coding:utf-8
# require "__dev/req" if $0 ==__FILE__

# --- ユーティリティ ---

module Merkle_tree_m_ex
  def TOP_NODE
    return up.up.TOP_NODE if up.up
    self
  rescue
    self
  end
  def TOP_SYM
    self.TOP_NODE.sym
  end
  # attr_accessor :MAIN_NODE
  def MAIN_NODE
    return self if task.any? { _1.sym == :__window_update }
    up ? up.MAIN_NODE : nil
  end
  # def MAIN_NODE=(v)
  #   @MAIN_NODE = v
  # end

  def delete
    task.each { _1.delete }
    up&.task.delete self
    task.clear
  end

  attr_accessor :vanish
  def vanish_update
    if vanish
      # p"vaniss---"
      # p o.sym
      delete
    end
  end
  def uniq_sym str = "_rb_uniq_" , n = rand(1000000)
    tmp = "#{str}_#{n}" #.to_sym
    if self.task.include? tmp
      return uniq_sym str , n + 1
    else
      return tmp
    end
  end # def
  # task.each(&:delete)
  # def task_delete
  #   delete
  #   up.delete
  # end
# selfより上の一番近い nodeを返す
  def search_up sym
    return self if self.sym =~ /#{sym}/
    return up.search_up sym if up
    false
  end
# テスト運用
  def sym_assoc(sym)
    { node: self, sym: sym , func: self.func ,
    }
  end
# 現状、sym確認用
->{
  "old"
  def search_up_all_sym = up ? [up.search_up_all_sym,sym]:[]
  def search_down_test o = self
    o.task.each.inject([]) do | stack , m |
      unless m.task.empty?
        next [stack , m.search_down_test(m)]
      end
      [stack , m.sym]
    end << o.sym
  end
}


# search系 == 戻り値 [要素] or []
#
  # ─ selfを含める with─
  def search_up_node = up ? [up] + up.search_up_node : []
  def search_up_sym = up ? [up.sym] + up.search_up_sym : []
  def search_up_node_with = [self] + search_up_node
  def search_up_sym_with = [self.sym] + search_up_sym
  def search_down_node = task.inject([]){|a,m| a + [m] + m.search_down_node }
  def search_down_sym = task.inject([]){|a,m| a + [m.sym] + m.search_down_sym }
  def search_down_node_with = [self] + search_down_node
  def search_down_sym_with = [self.sym] + search_down_sym

# 検索
# findはすべてノードを返す
# find_all == 戻り値 [要素] or []
# p o.search_up_find("top_node")
  def search_up_find_all t_sym ;search_up_node.select{|n| n.sym_prefix == self.sym_prefix(t_sym) } end
  def search_up_find_all_with t_sym ;([self] + search_up_node).select{|n| n.sym_prefix == self.sym_prefix(t_sym) } end
  def search_down_find_all t_sym ;search_down_node.select{|n| n.sym_prefix == self.sym_prefix(t_sym) } end
  def search_down_find_all_with t_sym ;([self] + search_down_node).select{|n| n.sym_prefix == self.sym_prefix(t_sym) } end

  def search_up_find(t_sym)
    result = search_up_node.find { |n| n.sym_prefix == self.sym_prefix(t_sym) }
    result ? [result] : []
  end
  def search_up_find_with(t_sym)
    result = search_up_node.find { |n| n.sym_prefix == self.sym_prefix(t_sym) }
    result ? [result] : []
  end
  def search_down_find(t_sym)
    result = search_down_node.find { |n|
      self.sym_prefix(n.sym) == self.sym_prefix(t_sym) }
    result ? [result] : []
  end
  def search_down_find_with(t_sym)
    result = search_down_node.find { |n|
      self.sym_prefix(n.sym) == self.sym_prefix(t_sym)
    }
    result ? [result] : []
  end
# すべての戻り値は [要素] or []
# findはすべてreturn ノード
#

#DEBUG ---－テスト用のメソッド
# nodes = some_node.search_down_regex_test(/^muteki/)
  def search_down_regex_test regex
    ([self] + search_down_node).select{|n| n.sym_prefix =~ regex }
  end
#
# --- lazy ---
  def delete_lazy wait
    Task do | o | o.Code do
      if wait < 0
        yield o if iterator?
        delete
      else
        wait -= 1
      end
  end end end
  def create_lazy wait
    Task do | o | o.Code do
      (wait < 0) ? yield(o) : (wait -= 1)
  end end end



# -------------  tree_libs
  def task_list_p(indent = 1 , first_call = true)
    # インデントを作成して、タスクの階層を見やすくする
    indent_str = '  ' * indent
    if first_call
      p "-#{self.sym} (up:#{self.TOP_SYM})"
    end
    unless task.empty?
      task.each_with_index do | o , i |
        # str = "(up:#{o.up ? o.up.sym : 'none'})" if i == 0 ; p "#{indent_str}├─ #{o.sym} #{str}"
        p "#{indent_str}├─ #{o.sym} (up:#{o.up ? o.up.sym : 'none'})"
        o.task_list_p(indent + 1 , false) unless o.task.empty?
      end
    end
    p "-----------"
  end

  def task_list(indent = 1, first_call = true, x = 10, y = 30)
    # インデントの文字列
    indent_str = '  ' * indent
    # str = "#{indent_str}├─ #{self.sym} (up:top_node)" if first_call

    # 最初のタスク情報を表示
    if first_call
      Window.draw_font(x, y, "-#{self.sym} (#{self.TOP_SYM})", Font.default)
      y += 30 # 次の行に移動
    end

    unless task.empty?
      task.each_with_index do |o, i|
        # 一番下の親タスクだけ赤色にする条件
        is_bottom_parent = !o.task.empty? && o.task.all? { |child| child.task.empty? }
        color = is_bottom_parent ? [200,150,150] : [200,200,200]

        task_str = "#{indent_str}├─ #{o.sym} (up:#{o.up ? o.up.sym : 'none'})"
        Window.draw_font(x, y, task_str, Font.default, color: color)
        y += 30 # 次の行に移動

        # サブタスクがあれば再帰的に表示
        o.task_list(indent + 2, false, x, y) unless o.task.empty?
      end
    end

    return y # 最後にyの位置を返すことで描画位置を更新
  end

  def tree_view_struct(obj, indent = 0)
    prefix = "  " * indent
    def attr_getters(obj)
      methods = obj.class.instance_methods
      # setter が存在するメソッドだけ getter とみなす
      methods.select { |m| !m.to_s.end_with?('=') && methods.include?("#{m}=".to_sym) && obj.method(m).arity == 0 }
    end
    getters = attr_getters(obj)
    # getters.each { |g| p "#{prefix}#{g}: #{obj.send(g).inspect}" }
    getters.each do |g|
      next if g == :DEBUG_CODE
      next if g == :func
      next if g == :!
      value = obj.send(g)
      # up と task は sym 表示に変換
      value = value.sym if g == :up && value.respond_to?(:sym)
      if g == :task && value.is_a?(Array)
        value = value.map { |n| n.sym rescue n }  # 各子ノードの sym に変換
      end
      p "#{prefix}#{g}: #{value.inspect}"
    end
    obj.task.each { |child| tree_view_struct(child, indent + 1) }
  end

  # o.sym_prefix(:user0_543t)             # => "user0"
  # o.sym_prefix(:user__444)   # => "user"
  # o.sym_prefix(:__window_434543)        # => "__window"
  # o.sym_prefix(:enemy_shot_983abc)      # => "enemy_shot"
  # o.sym_prefix(:enemy_983abc)      # => "enemy"
  def sym_prefix sym = self.sym
    sym.to_s[/^(_*[A-Za-z0-9]+(?:_[A-Za-z0-9]+)*?)(?=_[0-9]|$)/, 1]
  end
end

# -----------------------------------
#    ノードそれぞれにメッセージプロシージャを作る
#
# メッセージ処理の基盤モジュール。
# Taskメソッドをオーバーライドして_ms_prcoを埋め込み
# o._ms_send({
#  to: nil,
#  type: :a,
#  payload: ["hallo"]
# })


# -----------------------------------
module Node_ms_proc
  def subsc;       @subsc       ||= []; end
  def context;     @context     ||= {}; end
  def log_history; @log_history ||= []; end
  # selective dispatch
  def subsc?(msg_type)
    subsc.include?(msg_type)
  end
  def reset
    subsc.clear
    context.clear
    log_history.clear
  end
  # trace
  def trace
    log_history.dup
  end
  # 使うときに
  # task_tree.rb オーバーライド
  def _Task(sym = :task, &proc)
    super(sym, &->o{
      o._ms_proc ;proc.call(o)
    })
  end


  def _ms_send_private(msg)
    _ms_send(msg , :ms_private)
  end
  def _ms_send(msg , mode = :ms)
    raise ArgumentError, "message must be a Hash" unless msg.is_a?(Hash)
    # デフォルト補完
    msg[:from] ||= self.sym
    msg[:to]   ||= nil
    msg[:payload] ||= []
    msg[:to].Scarlet[ mode ] << msg
  end
  # semessag_proc
# type, payload, from = msg.values_at(:type, :payload, :from)
# o.log_history << { type: type, payload: payload, from: from, time: Time.now }
# def _ms_send(to, type, *payload)

  def _control_types; [:C, :D]; end
  def _normal_types;  [:A, :B]; end
  def _all_types;     _normal_types + _control_types; end
  def _control_type?(type); _control_types.include?(type); end
  def _normal_type?(type);  _normal_types.include?(type);  end

  def _ms_proc_private &block
    while (msg = self.Scarlet[:ms_private].shift)
      block[msg] if block
    end
  end
  # DefWndProc
  def def_window_proc msg
    case msg[:type]
    when ""
    else
    end
  end
  def _ms_proc &block
    o = self
    # p o.sym
    send_msg = o.Scarlet[:ms].dup
    while (msg = o.Scarlet[:ms].shift)
      # === 新: ハッシュ形式に対応 ===
      next u  nless msg.is_a?(Hash)

      to       = msg[:to]     || o.sym
      type     = msg[:type]
      payload  = msg[:payload] || []
      from     = msg[:from]    || :unknown

      if _control_type?(type) && (Symbol === to)
        warn "[WARN] #{type} should not specify a target (to=#{to.inspect})"
      end
      if _normal_type?(type) && !(Symbol === to)
        warn "[WARN] #{type} expects :to to be Symbol, got #{to.inspect}"
      end
      # === 宛先判定 ===
      # next unless to == o.sym || to == :all
      # === 履歴記録 ===
      log_history << { from: from, type: type, payload: payload, time: Time.now }

      _all_types.each do |t|
        if t == type
          p "Type #{t} registered"
          handler = "_#{t.to_s}"
          # send(handler, from, o, payload)
          o._ms.send(handler, send_msg)
        end
      end
    end
    # puts "[*] Scarlet[#{o.sym}] cleared (#{queue.empty?})"
  end
end

# def p(*args)
#   loc = caller(1..1).first   # 呼び出し元1行分
#   puts "[p] #{loc} => #{args.map(&:inspect).join(', ')}"
#   args.size <= 1 ? args.first : args
# end

# --------------------------------------
# module Node_ms_procのメッセージハンドラ
#   def _ms_proc
#     o._ms.send(handler, send_msg)
# 　
# --------------------------------------

module Node_ms_proc_handler
  def _ms
    @_ms ||= Ms_proxy.new(self)
  end
  class Ms_proxy
    def initialize(owner)
      @owner = owner
    end
    def get_state    = @state
    def set_state(v) = @state = v

    def _a(payload)
      p "[#{@owner.sym}] received :A → #{payload.inspect}"
    end

    def _b(payload)
      p "[#{@owner.sym}] received :B → #{payload.inspect}"
    end
    def _yield(payload)
      p "ms_yield run"
    end
  end
end
module Node_ms_proc
  # include Node_ms_proc_handler
end
