# ---------------------------------------------
#
#  2025/12/19
#  ruby 3.0.3p157 (2021-11-24 revision 3fb7d2cadc) [i386-mingw32]
#
#  gem install dxruby
#
# ---------------------------------------------


■ マインスイーパー  

■ 操作

・顔文字に左Click　リセット
・顔文字に中央Click　難易度選択



[実行] __run.rb 

[本体] AnneRose/app_mains.rb


以下、開発環境

[system]
  - tree_task.rb 
     treeモジュール
  - tree_task_ex.rb
     拡張

[project]
  - Merkle_tree.rb
      基幹ノードクラス定義
  - Merkle_default_class.rb
      Window.loop等フック
  - Merkle_tree_entry.rb
      定義したノードクラスの使用

[Lib2] ライブラリ

[AnneRose] 実行モジュール



■ これはなに？

汎用ツリーシステムからマインスイーパーだけ引っこ抜いたやつ


