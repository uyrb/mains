# -*- encoding: UTF-8 -*-
require 'dxruby'
if $0 ==__FILE__
end

class STACK
  attr_accessor :render
  attr_accessor :sound
  # attr_accessor :image
  def initialize
    @render = RenderQueue.new
    # @sound = Lazy_sound_loader.new # Lib2
    # @sound.load_sound(__dir__+"/sound")
    # @sound.load_sound_safeify
    return
  end
end

# ------- rect ----------


# ------- Render --------

class << Window
  alias_method :draw_original, :draw
  alias_method :drawEx_original, :drawEx
  alias_method :drawFont_original, :drawFont
  alias_method :drawFontEx_original, :drawFontEx
  alias_method :draw_font_original, :draw_font
  alias_method :draw_ex_original, :draw_ex
  alias_method :draw_font_ex_original, :draw_font_ex
end

def Window.draw(*v)
  if $Patchouli_knowledge.render.enable
    $Patchouli_knowledge.render.queue << { method: :draw, args: v }
  else
    draw_original(*v)
  end
end
# def Window.draw(*v)        ; $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :draw, args: v }        : draw_original(*v) ; end
def Window.drawEx(*v)      ; $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :drawEx, args: v }      : drawEx_original(*v) ; end
def Window.draw_ex(*v)     ; $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :draw_ex, args: v }     : draw_ex_original(*v) ; end
def Window.drawFont(*v)    ; $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :drawFont, args: v }    : drawFont_original(*v) ; end
def Window.drawFontEx(*v)  ; $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :drawFontEx, args: v }  : drawFontEx_original(*v) ; end
def Window.draw_font(*v)   ; $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :draw_font, args: v }   : draw_font_original(*v) ; end
def Window.draw_font_ex(*v); $Patchouli_knowledge.render.enable ? $Patchouli_knowledge.render.queue << { method: :draw_font_ex, args: v } : draw_font_ex_original(*v) ; end

class RenderQueue
  attr_accessor :queue, :enable
  def initialize
    # @queue = []
    @enable = true
  end
  def queue; @queue ||= []; end

# 一時停止
  def buf
    @buf ||= RenderTarget.new(Window.width, Window.height,[30,0,20])
    @buf
  end
  def draw_p
    @queue.each do |item|
      args = item[:args]
      case item[:method]
      when :draw ; buf.draw(*args)
      when :draw_ex, :drawEx ; buf.draw_ex(*args)
      when :draw_font, :drawFont ; buf.draw_font(*args)
      when :draw_font_ex, :drawFontEx ; buf.draw_font_ex(*args)
      else
        warn "Unknown render method: #{method_name}"
      end
    end
    @queue.clear

    # --- 新しいツリー作ってSceneに突入 ---
    $Patchouli_knowledge.render.enable = false
    Input.update
    Merkle_tree.new.Main :pause_node do |o|
      rb = :pause
      o.Scene_create rb # pause.rb
      o.Code do
        if Input.key_push?(K_P)
          o.delete;
        end
        Window.draw_font_original(240, 200, "PAUSED", Font.default)
        Window.draw_ex_original(0, 0, buf)
      end
    end
    Input.update
    $Patchouli_knowledge.render.enable = true
  end
  def draw
    if Input.key_push?(K_P)
      # draw_p # 一時停止
    end
  # 通常
    queue; #初期化
    @queue.each do |item|
      method_name = item[:method]
      args = item[:args]
      case method_name
      when :draw         then Window.draw_original(*args)
      when :drawEx       then Window.drawEx_original(*args)
      when :drawFont     then Window.drawFont_original(*args)
      when :drawFontEx   then Window.drawFontEx_original(*args)
      when :draw_font    then Window.draw_font_original(*args)
      when :draw_ex      then Window.draw_ex_original(*args)
      when :draw_font_ex then Window.draw_font_ex_original(*args)
      else
        warn "Unknown render method: #{method_name}"
      end
    end
    @queue.clear
  end
  def check_render_queue
    $Patchouli_knowledge.render.enable || queue.clear
    unless queue.empty?
      warn "[RenderQueue] queue not empty (#{queue.size} item(s))"
      queue.each_with_index do |item, i|
        warn "  ##{i+1}: method=#{item[:method]}, args=#{item[:args].map(&:inspect).join(', ')}"
      end
    end
    $Patchouli_knowledge.render.enable && draw
  end
end
# Sprite.drawは禁止にする
# _stub.rb yotei
# class Sprite
#   class << self
#     alias :draw_ :draw
#     def draw(*a); warn "[Sprite] draw called from #{caller(1..1).first}"; draw_(*a); end
#   end
# end
# あるいはSprite.drawをオーバーライド
class Sprite
  class << self
    alias :draw_ :draw
    def draw(m)
      case m
      when Array
        m.flatten.each { |m| Window.draw(m.x, m.y, m.image) }
      else
        # 配列でない場合
        Window.draw(m.x, m.y, m.image)
      end
    end
  end
end
class Sprite
  def self.check_fary a_ary, b_ary
    r = []
    a_ary.each{|ao| b_ary.each{|bo| Sprite.check(ao.sprite, bo.sprite) && r << [ao, bo]}}
    r.empty? ? nil : r
  end
  # AI高速化ver
  def self.check_fary a_ary, b_ary
    a_ary = [a_ary] if not  a_ary.is_a?(Array)
    b_ary = [b_ary] if not b_ary.is_a?(Array)
    a_sprite_ary = a_ary.map{|ao| ao.sprite}
    b_sprite_ary = b_ary.map{|bo| bo.sprite}
    r = []
    for i in 0...a_ary.length
      as = a_sprite_ary[i]
      for j in 0...b_ary.length
        Sprite.check(as, b_sprite_ary[j]) && r << [a_ary[i], b_ary[j]]
      end
    end
    r.empty? ? nil : r
  end
end # class



class Image
  def self.loader
    @yuyukosama ||= Lazy_image_loader.new
  end
    # def loader=(value) end
end

class Sound
  def self.loader
    if @yuyusama.nil?
      @yuyusama = Lazy_sound_loader.new
      # プラグインの中で行う
      # @yuyusama.load_sound(__dir__+"/sound")
      # @yuyusama.load_sound_safeify
    end
    @yuyusama
  end
end

# case  で一回限りの値取り出し
module Input_
    def mouse_wheel_prev
      @mouse_wheel_prev ||= 0
    end

    def mouse_wheel_prev=(v)
      @mouse_wheel_prev = v
    end

    # 上: 1、下: -1、動きなし: 0
    def mouse_wheel_updown
      delta = mouse_wheel_pos - mouse_wheel_prev
      self.mouse_wheel_prev = mouse_wheel_pos
      return 0 if delta == 0
      delta > 0 ? 1 : -1
    end
end

# ifで複数回 mouse_wheel_updown　取り出し BUG
# BUG 低確率で　1 or -1 の挙動、　謎
module Input_2
  class << self
    attr_accessor :_wheel_delta, :_wheel_updown
    # alias_method :update_orig, :update

    # 前回のマウスホイール位置
    def mouse_wheel_prev; @mouse_wheel_prev ||= mouse_wheel_pos; end
    def mouse_wheel_prev=(v); @mouse_wheel_prev = v; end

    # update の拡張
    def update
      result = update_orig   # 元の処理を最初に呼ぶ
      self.mouse_wheel_prev = mouse_wheel_pos
      # フレーム終了時に prev を更新
      result
    end

    # 1フレーム分の上下判定
    def mouse_wheel_updown
      delta = mouse_wheel_pos - mouse_wheel_prev
      return 0 if delta == 0
      delta > 0 ? 1 : -1
    end
  end
end



# --------------------------------------------------
#                     GLOBAL
# --------------------------------------------------

$Patchouli_knowledge = STACK.new
# $Patchouli_knowledge[:aa] =

SIN_TABLE = (0..359).map{|deg| Math.sin(deg * Math::PI/180)}
COS_TABLE = (0..359).map{|deg| Math.cos(deg * Math::PI/180)}
