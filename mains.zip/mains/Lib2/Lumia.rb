# -*- encoding: UTF-8 -*-



# -------------------------
# XXX m_button: M_RBUTTON XXX ここでボタン調整
# Clickable_state
class Button_state
  attr_accessor :pressed, :area_proc, :sym ,:win
  attr_accessor :on_push, :on_down, :on_release
  attr_accessor :on_hover, :on_leave
  attr_accessor :m_button
  attr_accessor :on_db_click , :last_push_time
  attr_accessor :true_proc
  alias on_db_push on_db_click
  alias on_db_push= on_db_click=
  # mbutton #TODO　ではなく key_push配列を渡す　と非アクティブ対応
  def initialize(sym: "button_state_class" , win: nil , m_button: M_LBUTTON , area_proc: nil, on_push: nil, on_down: nil, on_release: nil, on_hover: nil, on_leave: nil, on_db_click: nil,true_proc: nil)
    @sym     = sym
    @win     = win  # win.z だけ使う　 XXX
    @m_button = m_button
    @pressed = false
    @area_proc = area_proc || ->{[0,0,0,0]}
    @on_down = on_down
    @on_push = on_push
    @on_release = on_release
    @on_hover = on_hover
    @on_leave = on_leave
    #
    @on_db_click = on_db_click
    @last_push_time = 0
    @true_proc = true_proc || ->{ true } # デフォルトでtrue
  end

  def is_leave?(lx, ly)
    @was_inside && is_hover?(lx, ly)
  end
  def is_hover?(lx, ly)
    inside?(lx, ly, *@area_proc.call)
  end
  def active? = @true_proc.call
  def update(lx, ly)
    return false unless active?  # ← アクティブでなければ処理しない

    if is_hover?(lx, ly)
      @was_inside = true
      @on_hover&.call
    else
      if @was_inside
        @on_leave&.call   # ★ leave イベント実行
        @was_inside = false
      end
    end

    # --- ダブルクリック判定を完全に独立 ---
    if Input.mouse_push?(@m_button) && inside?(lx, ly, *@area_proc.call)
      now = Time.now.to_f
      if (now - @last_push_time) < 0.3
        @on_db_click&.call
      end
      @last_push_time = now
    end

    if Input.mouse_push?( @m_button ) && inside?(lx, ly, *@area_proc.call)
      @pressed = true
      @on_push&.call
    elsif @pressed && Input.mouse_down?( @m_button )
      @on_down&.call
    elsif @pressed && Input.mouse_release?( @m_button )
      @on_release&.call if inside?(lx, ly, *@area_proc.call)
      @pressed = false
    end
    return @pressed
  end

  def inside?(lx, ly, x0, y0, x1, y1)
    lx >= x0 && lx <= x1 && ly >= y0 && ly <= y1
  end

  # キーなどから「代理で押す」ための最小 API
  def _em_on_push(lx, ly)
    if inside?(lx, ly, *@area_proc.call)
      @pressed = true
      @on_push&.call
    end
  end
  def _em_on_down = @on_push&.call
  def _em_on_release
    if @pressed
      @on_release&.call if inside?(lx, ly, *@area_proc.call)
      @pressed = false
    end
  end
end # c



def mouse_pos_hit x , y , w , h
  Input.mouse_pos_x >= x &&
     Input.mouse_pos_x <  x + w &&
     Input.mouse_pos_y >= y &&
     Input.mouse_pos_y <  y + h
end
def mouse_pos_hit_node(o)
  Input.mouse_pos_x >= o.x &&
    Input.mouse_pos_x <= o.x + o.d.width  &&
    Input.mouse_pos_y >= o.y &&
    Input.mouse_pos_y <= o.y + o.d.height
end



module Rumia
  module_function
  # 1フレームごとに target に向かって移動 (固定速度)
  # x, y : 現在座標
  # t_x, t_y : 目標座標
  # speed : 1フレームで移動する距離(px)
  def move_toward(x, y, t_x, t_y, speed)
    dx = t_x - x
    dy = t_y - y
    dist = Math.sqrt(dx**2 + dy**2)
    return [t_x, t_y] if dist <= speed || dist == 0
    ratio = speed / dist
    [x + dx * ratio, y + dy * ratio]
  end
  # イージング付き移動（速度は距離に比例して減衰）
  # factor : 0.0〜1.0 で 1 に近いほどゆっくり止まる
  def ease_move(x, y, t_x, t_y, factor = 0.1)
    dx = t_x - x
    dy = t_y - y
    [x + dx * factor, y + dy * factor]
  end
  # 線形補間 (lerp) 移動
  # t : 0.0〜1.0, t=0 現在座標, t=1 目標座標
  def lerp_move(x, y, t_x, t_y, t)
    x_new = x + (t_x - x) * t
    y_new = y + (t_y - y) * t
    [x_new, y_new]
  end
end



module Lumia
  class << self
    include Lumia
# C 実装やめた 9倍遅い
#    include Last_Lib
  end

  def repl s
     (s =~ /\(.*?(\(.*)\)/ ? s.sub($1,(repl $1).to_s) : s).scan(/\((.*?)\s(.*)\)/).flatten.last.split.map(&:to_f).inject *(eval "[$1=~/[a-z|A-Z]/,:#{$1}].compact")
  end
#  repl"(print (+ 8 9))"
#  puts
#  p repl"(* 8 9 5 5 5 5)"
#  repl"(p (* 59 5 (* 4 (/ 10 6))))"

  def recursion &b
    f = ->*n{ b[ *n , &f ] }
  end

  def y_combinator &b
    lambda do |f|
      lambda{|x|lambda{|y| f[x[x]] [y]}}[
        lambda{|x|lambda{|y| f[x[x]] [y]}}]
    end[ lambda{|f|lambda{|n| b[n , &f] }}]
  end

  def require file
    super File.dirname(__FILE__) + "/" + file
  end
  def extsplit s
    s =~ /(.*)\.(.*)/
    return $1 , $2
  end
  def ary_nest a,n
    return a if n <= 0
    ary_nest [].push(a) , n-1
  end
  # def ary_nest_ai(a, n) = n.times.reduce(a) { |acc, _| [acc] }
  def ary2 a , b , c = 0
    (0...a).map do (0...b).map do c end end
  end
  # def ary2_ai(a, b, c = 0) = Array.new(a) { Array.new(b, c) }

  def blockhit x1 , y1 , w1 , h1 , x2 , y2 , w2 , h2
    x1 + w1 > x2 && x1 < x2 + w2 && y1 + h1 > y2 && y1 < y2 + h2
  end
  def work x , y , s , a
    x += (s * Math::cos(a * Math::PI/180 ))
    y += (s * Math::sin(a * Math::PI/180 ))
    [x , y , s , a]
  end

  # ラジアン不要vr
  # 915 → 910にする形のテーブル化高速化の案
  def firstatan_rad x , y, xxx, yyy
     return Math.atan2( yyy - y , xxx - x )
  end

  def work_table(x, y, s, a)
    x += COS_TABLE[a % 360] * s
    y += SIN_TABLE[a % 360] * s
    return x, y, s, a
  end
  def work_rad(x, y, s, a_rad)
    x += s * Math.cos(a_rad)
    y += s * Math.sin(a_rad)
    [x, y, s, a_rad]
  end
  # -------rad------------

# @now = Process.clock_gettime(Process::CLOCK_MONOTONIC)
# @delta = @now - @prev
# @prev = @now
# Process.clock_gettime(Process::CLOCK_MONOTONIC)
  # def work(x, y, s, a, delta = 1.0)
  #   rad = a * Math::PI / 180.0
  #   x += (s * Math.cos(rad)) * delta
  #   y += (s * Math.sin(rad)) * delta
  #   [x, y, s, a]
  # end

  def circle_pixel_hit x1,  y1,  w1,  h1,  r1, x2,  y2,  w2,  h2,  r2
    return (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2) - r1*r2 <= 0
  end
  # ｗ/２ まで関数で計算する
  def circlehit2 x1, y1, w1, h1, r1, x2, y2, w2 , h2 , r2
    x1 = x1+w1/2
    y1 = y1+h1/2
    y2 = y2+h2/2
    x2 = x2+w2/2
    return ((x1-x2)**2+(y1-y2)**2)-((r1+r2)**2) <= 0
  end
  # ｗ / ２ を考慮しない
  def circlehit x1, y1, w1, h1, r1, x2, y2, w2 , h2 , r2
    x1 = x1+w1
    y1 = y1+h1
    y2 = y2+h2
    x2 = x2+w2
    return ((x1-x2)**2+(y1-y2)**2)-((r1+r2)**2) <= 0
  end

  def DegToRad x
    x*Math::PI/180
  end
  def RadToDeg x
    x*180/Math::PI
  end
  def firstatan x , y, xxx, yyy
     return RadToDeg( Math.atan2( yyy - y , xxx - x ))
  end

  def homing x , y , xxx , yyy , angle , as
    tmp = homing_angle x , y, xxx , yyy
    angle += as if angle < tmp
    angle -= as if angle > tmp
    angle
  end

  def homing_ai(x, y, target_x, target_y, angle, turn_rate)
    target_angle = homing_angle(x, y, target_x, target_y)  # 目標角度
    delta = target_angle - angle
    # ±180° 補正 瞬間角度への最短角度がプラスかマイナスか
    # delta を -180°〜180° の範囲に収める
    delta -= 360 if delta > 180
    delta += 360 if delta < -180
    # turn_rate で制限
    delta = [[delta, turn_rate].min, -turn_rate].max
    angle + delta
  end

  #--------------------------
  def get_center xy, wh , len
     xy + ( wh * 0.5 ) - ( len * 0.5 )
  end

  alias move work
  alias homing_angle firstatan

end

=begin
# rubyex.rbに移動、SafeOpenStruct_mも定義
module OpenStruct_m
  def method_missing( name , *arg )
    if arg.size == 0
      str =  <<TEXT
      def #{name}
        @#{name}
      end
      @#{name}
TEXT
    elsif name.to_s.include? "="
      str =  <<TEXT
      def #{name} miyu
        @#{name} miyu
      end
      self.#{name} arg[0]
TEXT
    else
      p __method__ , str , name , arg , caller
      exit
    end
#    puts str
    instance_eval str
  end
end
module Suika
  include OpenStruct_m
end
#o = Object.new;o.extend OpenStruct_m; p o.r = 9
=end

# lib izonn kei
module Lumia2

  class << self
    def window_sprite = @window_sprite_73648 ||= Sprite.new(0, 0, Image.new(Window.width, Window.height, [40,40,40]))

    def rect_delete o
      unless Lumia.blockhit o.x , o.y , o.d.width , o.d.height ,
         -100 , -100 , Window.width+200 , Window.height+200
         o.delete
      end
    end

    def hit_check_box o , m
      o.x + o.d.width  > m.x && o.x < m.x + m.d.width &&
        o.y + o.d.height > m.y && o.y < m.y + m.d.height
    end

    def get_yy_center a , b
       [ a.x + (a.d.width/2) - (b.d.width/2) , a.y + (a.d.height/2) - (b.d.height/2) ]
    end
    def get_homing_center o , v
      vx = v.x + v.d.width  / 2 - o.d.width  / 2
      vy = v.y + v.d.height / 2 - o.d.height / 2
      [ vx , vy ]
    end

  end
# Image と Sound の ロード関数を一緒にするための記述
# Soundクラス直でいじると、上書きを行っても、おそらくは
# C++実装のほうのloadを読んでる為、引数エラーが起きるので継承で回避
  class My_Sound < Sound
    class << self
      alias_method :load , :new
    end
  end
  class << self
    # [[]] 0.wav
    def Sound_load pas  ,  patan = "{wav}"
      load( pas , My_Sound , patan )
    end
    # []
    # def Sound_load_miko pas  , patan = "{wav}"
    #   __ImageSound_load_miko pas , My_Sound  , patan
    # end
    # Sound
    # def Sound_load_alice pas
    #   Image_load_alice pas , Sound
    # end
    # def __ImageSound_load_miko pas , remi , patan
    #   a = load( pas , remi , patan )
    #   if a.empty? || a.class != Array
    #     p "#{__method__} pas is not directory #{pas} #{remi}"
    #     p caller
    #   end
    #   return  a.flatten - []
    # end


    # [[]] ,  0.bmp
    def Image_load pas  , patan = "{png,bmp,jpg,jpeg,gif}"
      load( pas , Image , patan  )
    end
    # []
    # def Image_load_miko pas , patan = "{png,bmp,jpg,jpeg,gif}"
    #   __ImageSound_load_miko  pas , Image  , patan
    # end
    # Image
    # def Image_load_alice  pas  ,  remi = Image
    #   a = load( pas , remi , "{" + "#{File.extname(pas)}" + "}" )
    #   if a.empty? || a.class == Array
    #     p "#{__method__} pas is not file #{pas} #{remi}"
    #     p caller
    #   end
    #   return  a
    # end
    # lambdaの中でローカル変数がヒープ領域化
    # stkは三次元配列, mikoは二次元配列 stk[-1]の参照渡しと思われる
    # dirはstkに対するハッシュkey代わり
    #
    #     外からのアクセスを確立した場合のclear方法
    #      $STACK.remilia[:load][:dir].clear
    #      $STACK.remilia[:load][:stk].clear
    #      $STACK.remilia[:load][:stk] = [[]]
    def load s , remi , patan
      stk = [[]]
      dir = []
      # メソッドの外からアクセス可能にする
      # $STACK.remilia[:load][:dir] ||= []   ###
      # $STACK.remilia[:load][:stk] ||= [[]] ###
      (@@load_sub___stack___ ||= lambda do | s , remi , patan |
        # dir = $STACK.remilia[:load][:dir]  ###
        # stk = $STACK.remilia[:load][:stk]  ###
         if dir.index s
            return stk[dir.index(s)] if File.directory?(s)
            return stk[dir.index(s)][0][0]
         end
         miko = stk[-1]
         if File.directory?(s)
             Dir["#{s}/*"].select do | m |
               File.directory? m
             end.each_with_index do | kd , k |
               miko << Dir[ "#{s}/#{k}/*."+patan ].map do | m |
                # miko[k] = Dir[ "#{kd}/*."+patan ].map do | m |  # 0 1 2 じゃなく任意のフォルダ名
               remi.load m
             end
           end
           # 指定したフォルダパスに
           # 0 1 2 の フォルダがない時はパスのファイルを1次元配列で読む
           if miko.empty? # 多次元配列読み込みじゃなければ、一次元配列読み込み
             miko << Dir[ "#{s}/*."+patan ].map do | m |
                remi.load( m )
             end
           end
           # 二次元配列return
           dir << s
           stk << []
           return miko
         elsif File.file?(s)
           # ファイル単体の場合のstkの格納場所 stk[s][0][0]
           miko << []
           miko[0][0] = remi.load s
           dir  << s
           stk  << []
           return miko[0][0]
         end
         p "err2"
      end).call( s , remi , patan )
    end
  end

  def self.screenshot dir = "_screenshot"
     pwd = Dir.pwd
     Dir.chdir File.dirname($0)
     Dir.mkdir( dir ) unless File.exist?( dir )
     file  =  dir + "/screenshot" + Time.new.strftime("%Y%m%d%H%M%S") + ".jpg"
     Window.getScreenShot( file )
     Dir.chdir pwd
     return file
  end

end



# 末尾再帰最適化の
class Module
  def recursion_tco func
    func_p = "_tco_#{func}"
    alias_method func_p , func

    nanoha = "nanoha_kannbai"
    arg  = nil
    ff   = true
    define_method func do | *h |
      [ff=nil].cycle do |re|
        return re if ff = (re = method(func_p)[*h]) != nanoha
        h = arg
      end if ff
      arg = h
      nanoha
    end
  end # def
end
=begin
class A
  def f n , a = 1
    if  n  ==  0
       a
    else
       f(n  -  1 , a * n)
    end
  end
  recursion_tco :f
end
p A.new.f 20000
=end
