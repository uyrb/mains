#coding:utf-8
# require "__dev/req"  if $0 ==__FILE__

# ---------------------------
# リファレンス
# https://mirichi.github.io/dxruby-doc/
#
# ----------- init ----------
# last.rb Re:dev 2025 10~
#
#
# ---------------------------


#Window.load_icon "./icon/"
Window.caption = ""
Window.x       = 40
Window.y       = 40
Window.width   = 640
Window.height  = 480
Window.width   = 1280
Window.height  = 720
# rect 900 , 680
# up , down 20
# left  40   right 340


Window.windowed = true
#1280×720
#Window.windowed = false
Window.fps = 60
# Window.frameskip?
# Window.frameskip=val
# Window.frameskip = true
Window.bgcolor = [10,10,10]
Window.create
